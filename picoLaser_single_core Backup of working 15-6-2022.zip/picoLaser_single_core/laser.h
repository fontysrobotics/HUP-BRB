//This code was written for the raspberry pi pico 
//Company:                  Fontys
//Maker of file:            Wouter Mulder 
//Last edded by:            Wouter Mulder 
//Date of file creation:    10-5-2022
//Date of last edded:       10-5-2022

//This function is to turn on and off the laser 
//enable            =   True or false to turn laser on or off 
//laserEnablePin    =   Pin number where laser is connected 
void laserEnable(bool enable, uint laserEnablePin);