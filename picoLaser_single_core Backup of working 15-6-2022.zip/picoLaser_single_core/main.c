//This code was written for the raspberry pi pico 
//Company:                  Fontys
//Maker of file:            Wouter Mulder 
//Last edded by:            Wouter Mulder 
//Date of file creation:    10-5-2022
//Date of last edded:       3-6-2022
//This code was written for one core of the raspberry pi pico 

#include "global.h"
#include <stdio.h>
#include <stdint.h>
#include "pico/stdlib.h"
#include "pico.h"
#include "hardware/structs/adc.h"
#include "hardware/gpio.h"
#include "hardware/adc.h"
#include "pico/multicore.h"
#include "laser.h"
#include "serial.h"
#include "statemachine.h"
#include "pwm.h"
//#include "hardware/watchdog.h"



void PINSETUP(){
    //setup the ADC for current sensing
    adc_gpio_init(current_sense_X_pin);
    adc_gpio_init(current_sense_Y_pin);
    adc_select_input(current_sense_X);
    adc_select_input(current_sense_Y);

    //GPIO init function will initialoize the GPIO pins 
    gpio_init(RGB_green);
    gpio_init(RGB_red);
    gpio_init(RGB_blue);
    gpio_init(laser_enable);

    //GPIO set direction will make the pins input or output
    gpio_set_dir(RGB_green, GPIO_OUT);
    gpio_set_dir(RGB_red, GPIO_OUT);
    gpio_set_dir(RGB_blue, GPIO_OUT);
    gpio_set_dir(laser_enable, GPIO_OUT);
    
    //GPIO set all initial states to OFF
    gpio_put(RGB_red, RGB_OFF);
    gpio_put(RGB_green, RGB_OFF);
    gpio_put(RGB_blue, RGB_OFF);

}



int main(void){
    
    States stateCoreZero = SerialListen;
    static uint32_t dataFromCore1[3];
    char serialString[STRINGSIZE];
    struct motorPins motorXcore0;
    struct motorPins motorYcore0;
    
    //watchdog_enable(1000, 1);
    adc_init();
    PINSETUP();
    PWMSETUP();
    SERIALINIT();
    stdio_init_all();        // Initialize chosen serial port
    laserEnable(laser_OFF, laser_enable);   //Trun off laser for safety 



    serialString[1] = '+';
    
    serialString[2] = '1';
    serialString[3] = '0';
    serialString[4] = '0';
    
    serialString[5] = '1';
    serialString[6] = '0';
    serialString[7] = '0';

    //The state machine for the cor zero, core one is sitting idle this is a upgrade we/you can do
    while(true){
        switch(stateCoreZero){
            case(SerialListen):
            SerialListenState(&stateCoreZero, serialString);
            break;

            case(CalculateResults):
            CalculateResultState(&stateCoreZero, serialString, &motorXcore0, &motorYcore0);
            break;

            case(outputResults):
            outputResultsState(&stateCoreZero, &motorXcore0, &motorYcore0);
            break;

            case(error):
            errorState();
            break;

            default:
            stateCoreZero = SerialListen;
            break;
        }
    }
}