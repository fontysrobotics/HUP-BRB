//This code was written for the raspberry pi pico 
//Company:                  Fontys
//Maker of file:            Wouter Mulder 
//Last edded by:            Wouter Mulder 
//Date of file creation:    10-5-2022
//Date of last edded:       10-5-2022
#include <stdint.h>
#include "global.h"
#include "pico/stdlib.h"
#include "pico.h"
#include "hardware/structs/adc.h"
#include "hardware/gpio.h"
#include "hardware/adc.h"
#include "pico/multicore.h"
#include "hardware/structs/adc.h"
#include "hardware/gpio.h"
#include "hardware/pwm.h"
#include "pwm.h"

void PWMSETUP(void){
    gpio_set_function(WL_X, GPIO_FUNC_PWM);
    gpio_set_function(WH_X, GPIO_FUNC_PWM);
    gpio_set_function(VL_X, GPIO_FUNC_PWM);
    gpio_set_function(VH_X, GPIO_FUNC_PWM);
    gpio_set_function(UL_X, GPIO_FUNC_PWM);
    gpio_set_function(UH_X, GPIO_FUNC_PWM);

    gpio_set_function(WL_Y, GPIO_FUNC_PWM);
    gpio_set_function(WH_Y, GPIO_FUNC_PWM);
    gpio_set_function(VL_Y, GPIO_FUNC_PWM);
    gpio_set_function(VH_Y, GPIO_FUNC_PWM);
    gpio_set_function(UL_Y, GPIO_FUNC_PWM);
    gpio_set_function(UH_Y, GPIO_FUNC_PWM);

    pwm_set_wrap(pwm_gpio_to_slice_num(WL_X), numberOfPwmCycles);
    pwm_set_wrap(pwm_gpio_to_slice_num(WH_X), numberOfPwmCycles);
    pwm_set_wrap(pwm_gpio_to_slice_num(VL_X), numberOfPwmCycles);
    pwm_set_wrap(pwm_gpio_to_slice_num(VH_X), numberOfPwmCycles);
    pwm_set_wrap(pwm_gpio_to_slice_num(UL_X), numberOfPwmCycles);
    pwm_set_wrap(pwm_gpio_to_slice_num(UH_X), numberOfPwmCycles);

    pwm_set_wrap(pwm_gpio_to_slice_num(WL_Y), numberOfPwmCycles);
    pwm_set_wrap(pwm_gpio_to_slice_num(WH_Y), numberOfPwmCycles);
    pwm_set_wrap(pwm_gpio_to_slice_num(VL_Y), numberOfPwmCycles);
    pwm_set_wrap(pwm_gpio_to_slice_num(VH_Y), numberOfPwmCycles);
    pwm_set_wrap(pwm_gpio_to_slice_num(UL_Y), numberOfPwmCycles);
    pwm_set_wrap(pwm_gpio_to_slice_num(UH_Y), numberOfPwmCycles);
    
}

void pwmSet(uint8_t pwmPin, uint8_t PWM){
    uint slice_num = pwm_gpio_to_slice_num(pwmPin); //Get silce number from gpio pin 

    //bool BTrue = pwmPin % 2;                        //Get if A or B
    uint chan = pwm_gpio_to_channel(pwmPin);         //Get channel for PWM 
    //pwm_set_enabled(slice_num, false);             //Turn PWM off on pin 
    pwm_set_chan_level(slice_num, chan, PWM);      //Set new pwm level 
    //pwm_set_freq_duty(slice_num, chan, 250, PWM);
    pwm_set_enabled(slice_num, true);               //Trun on PWM
}