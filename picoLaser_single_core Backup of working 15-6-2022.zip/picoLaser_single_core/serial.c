//This code was written for the raspberry pi pico 
//Company:                  Fontys
//Maker of file:            Wouter Mulder 
//Last edded by:            Wouter Mulder 
//Date of file creation:    10-5-2022
//Date of last edded:       10-5-2022

#include "global.h"
#include <stdio.h>
#include "pico/stdlib.h"
#include "pico.h"
#include "hardware/structs/adc.h"
#include "hardware/gpio.h"
#include "hardware/uart.h"
#include "serial.h"
#include <stdint.h>

void SERIALINIT(void){
   
   gpio_put(RGB_red, RGB_ON);
   gpio_put(RGB_blue, RGB_ON);

   //Init function to setup USB serial at 115200 baud
   uart_init(uart1, 115200);
   uart_init(uart0, 115200);

   // gpio_set_function(0, GPIO_FUNC_UART);
   // gpio_set_function(1, GPIO_FUNC_UART);

   // uart_set_format(uart1, 8, 1, UART_PARITY_NONE);
   // uart_set_format(uart0, 8, 1, UART_PARITY_NONE);

   // uart_set_fifo_enabled(uart1, true);
   // uart_set_fifo_enabled(uart0, true);

   sleep_ms(500);
   gpio_put(RGB_red, RGB_OFF);
   gpio_put(RGB_blue, RGB_OFF);
}


void serial_in(uint8_t *data[30]){
   //scanf("%1024s", *data);
   //printf("%s\n", *data);
   uint8_t character[30];    //set all bits to zero

   uint8_t counter = 0;
   while (uart_is_readable(0) == true){    //Read characters as long as there are charactes to be read in from serial uart bus 
      character[counter] = uart_getc(0);
      counter++;
      //asm("NOP");
   }

   *data = character;    //send the data recived back to main code 
}