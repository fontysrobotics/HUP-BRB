//This code was written for the raspberry pi pico 
//Company:                  Fontys
//Maker of file:            Wouter Mulder 
//Last edded by:            Wouter Mulder 
//Date of file creation:    10-5-2022
//Date of last edded:       11-5-2022

//Included header fils 
#include "statemachine.h"
#include "pwm.h"
#include "global.h"
#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include "pico/stdlib.h"
#include "pico.h"
#include "pico/stdio_usb.h"
#include "hardware/structs/adc.h"
#include "hardware/gpio.h"
#include "hardware/adc.h"
#include "hardware/uart.h"
#include "pico/multicore.h"
#include "serial.h"

#define max(X, Y) (((X) > (Y)) ? (X) : (Y))

int SerialListenState(States *stateInBlock, char serialString[]){
    
    //Make local variables 
    int tempString;
    bool blink = false;
    int idx = 0;
    
    //While idex is smaller than string size (7)
    while(idx<STRINGSIZE)
    {
        gpio_put(RGB_blue, RGB_ON);                 //Turn blue LED on 
        tempString = getchar_timeout_us(50000);     //Check serial buffer for characters time out afther 5 sec
        
        if (tempString < 0){                        //If string size is done turn LED off and jump out of while loop 
            gpio_put(RGB_red, RGB_OFF);
            break;
        }

        serialString[idx++] = (char) tempString;    //Put incomming character serial string in position idex 
    }

    gpio_put(RGB_blue, RGB_OFF);                    //Turn LED off 

    *stateInBlock = CalculateResults;               //Jump to calculate result state 
    return idx;                                     //Return idex 

    
}

void CalculateResultState(States *stateInBlock, char serialString[], struct motorPins *motorX, struct motorPins *motorY){
    //Make local varable
    static uint32_t time = 0;
    time++;        
    char xString[3];
    char yString[3];
    
    //Read serial string and copy part of string for later processing 
    strncpy(xString, (serialString + 1), 3);
    strncpy(yString, (serialString + 4), 3);
    
    //Calculate xy axis displasment 
    int16_t X_val = atoi(xString);                          //Make interger value from xString 

    if (serialString[0] == '-'){                            //See if X value need to be negative 
        X_val = X_val * -1;
    }

    int16_t Y_val = atoi(yString);                          //Make interger value from yString
    //printf("%d, %d\r\n", X_val, Y_val);
   
    float period = 50.0;                                    //Make a periode of 50 for calculations 

    //Calculate the sine and cosine functions 
    float x_axis = X_val * sin(6 * PI * time/period) + X_val;
    float y_axis = Y_val * cos(12 * PI * time/period);

    // printf("%f, %f\r\n", x_axis, y_axis);                //Print the X and Y displasement 

    //Set motor X
    int16_t UX = numberOfPwmCycles * sin(x_axis);           //Phase U
    int16_t VX = numberOfPwmCycles * sin(x_axis + PHI);     //Phase V
    int16_t WX = numberOfPwmCycles * sin(x_axis - PHI);     //Phase W

    //printf("%d, %d, %d\r\n", UX, VX, WX);

    (*motorX).UL = max(0, (-1 * UX));
    (*motorX).UH = max(0,  UX);
    (*motorX).VL = max(0, (-1 * VX));
    (*motorX).VH = max(0,  VX);
    (*motorX).WL = max(0, (-1 * WX));
    (*motorX).WH = max(0,  WX);


    //Set motor Y 
    int16_t UY = numberOfPwmCycles * sin(y_axis);          //Phase U
    int16_t VY = numberOfPwmCycles * sin(y_axis + PHI);    //Phase V
    int16_t WY = numberOfPwmCycles * sin(y_axis - PHI);    //Phase W

    (*motorY).UL = max(0, (-1 * UY));
    (*motorY).UH = max(0,  UY);
    (*motorY).VL = max(0, (-1 * VY));
    (*motorY).VH = max(0,  VY);
    (*motorY).WL = max(0, (-1 * WY));
    (*motorY).WH = max(0,  WY);
    
    *stateInBlock = outputResults;
}

void outputResultsState(States *stateInBlock, struct motorPins *motorX, struct motorPins *motorY){
    
    laserEnable(laser_ON, laser_enable);   //Trun laser on for display  
    
    //Set pwm from data in motor structs 
    pwmSet(WL_X, (*motorX).WL);
    pwmSet(WH_X, (*motorX).WH);
    pwmSet(VL_X, (*motorX).VL);
    pwmSet(VH_X, (*motorX).VH);
    pwmSet(UL_X, (*motorX).UL);
    pwmSet(UH_X, (*motorX).UH);

    pwmSet(WL_Y, (*motorY).WL);
    pwmSet(WH_Y, (*motorY).WH);
    pwmSet(VL_Y, (*motorY).VL);
    pwmSet(VH_Y, (*motorY).VH);
    pwmSet(UL_Y, (*motorY).UL);
    pwmSet(UH_Y, (*motorY).UH);
    

    //Read ADC 
    adc_select_input(current_sense_X);
    uint16_t adc_value_x = adc_read();

    adc_select_input(current_sense_Y);
    uint16_t adc_value_y = adc_read();
  
    //Calculate voltage
    float voltage_X = (adc_value_x * 3.3) / 4096;
    float voltage_Y = (adc_value_y * 3.3) / 4096;

    //Calculate corrent through X and Y motors 
    float current_X = voltage_X / Rsense;
    float current_Y = voltage_Y / Rsense;

    //Check to see if current is over limit
    if (current_X > CURRENTLIMIT || current_Y > CURRENTLIMIT){
        *stateInBlock = error;
    }

    else{
        *stateInBlock = SerialListen;
    }
    
}

void errorState(){      //This is the error state this code SHOULD not be reatched in normal operation but is is there if there is a problem detected. 

    //Stop all motion!
    pwmSet(WL_X, 0);
    pwmSet(WH_X, 0);
    pwmSet(VL_X, 0);
    pwmSet(VH_X, 0);
    pwmSet(UL_X, 0);
    pwmSet(UH_X, 0);

    pwmSet(WL_Y, 0);
    pwmSet(WH_Y, 0);
    pwmSet(VL_Y, 0);
    pwmSet(VH_Y, 0);
    pwmSet(UL_Y, 0);
    pwmSet(UH_Y, 0);
    
    //Trun off laser for safety 
    laserEnable(laser_OFF, laser_enable);   

    //Turn red led on to indicate problem 
    gpio_put(RGB_blue, RGB_OFF);
    gpio_put(RGB_green, RGB_OFF);
    
    gpio_put(RGB_red, RGB_ON);
    sleep_ms(250);
    gpio_put(RGB_red, RGB_OFF);
    sleep_ms(250);
    
}