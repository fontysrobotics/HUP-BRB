//This code was written for the raspberry pi pico 
//Company:                  Fontys
//Maker of file:            Wouter Mulder 
//Last edded by:            Wouter Mulder 
//Date of file creation:    10-5-2022
//Date of last edded:       10-5-2022

#include "global.h"
#include <stdio.h>
#include "pico/stdlib.h"
#include "pico.h"
#include "hardware/structs/adc.h"
#include "hardware/gpio.h"
#include "hardware/adc.h"
#include "pico/multicore.h"
#include "laser.h"

void laserEnable(bool enable, uint laserEnablePin){
    if (enable == true){
        gpio_put(laserEnablePin, true);
    }

    else{
        gpio_put(laserEnablePin, false);
    }
}