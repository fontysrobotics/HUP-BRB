//This code was written for the raspberry pi pico 
//Company:                  Fontys
//Maker of file:            Wouter Mulder 
//Last edded by:            Wouter Mulder 
//Date of file creation:    10-5-2022
//Date of last edded:       3-6-2022

//#include "global.h"
#include <stdint.h>
#include <stdbool.h>

#define STRINGSIZE      7

//Defining states for statemachine 
//States for core 0 state machine 
typedef enum{
    SerialListen,
    CalculateResults,
    outputResults,
    error
} States;

//The struckt for motor PWM
struct motorPins{
    uint8_t WL;            
    uint8_t WH;            
    uint8_t VL;            
    uint8_t VH;            
    uint8_t UL;            
    uint8_t UH;            
};

struct errorSignalsCore0{
    bool notReady;
    bool laserProblem;
    bool motorProblen;
    bool overCurrent;
    bool notReadingCoreOne;
};

//The serial lissen state is a state machine function programmed to lissen to the serial bus. 
//stateInBlock  =   the state it is currently in. This will also return the state the program needs to go to 
//serialString  =   This string it read from the serial port (7 characters)
int SerialListenState(States *stateInBlock, char serialString[]);

//The CalcutaleResultState is the state that takes in the information from the Serial listen state and truns it into something the motors can understand 
//stateInBlock  =   the state it is currently in. This will also return the state the program needs to go to 
//serialString  =   This string it read from the serial port (7 characters)
//motorX        =   Is a pointer variable that is used to sent the motor X pwm signals 
//motorY        =   Is a pointer variable that is used to sent the motor Y pwm signals 
void CalculateResultState(States *stateInBlock, char serialString[], struct motorPins *motorX, struct motorPins *motorY);

//The outputResultState is the state where the output of the CalculateResultState gets put onto the pwm pins to drive the motors 
//stateInBlock  =   the state it is currently in. This will also return the state the program needs to go to 
//motorX        =   Is a pointer variable that is used to sent the motor X pwm signals 
//motorY        =   Is a pointer variable that is used to sent the motor Y pwm signals
void outputResultsState(States *stateInBlock, struct motorPins *motorX, struct motorPins *motorY);

//The error state is a state that should NOT be reached durring normal operation. 
//This state is to propect the system from over current.
//When there is an overcurrent situation the system will stop PWM and give a RED led on the board to indicate thet this state has bin reaged 
//This state can only be exited by manualy restating the system this is by design.
void errorState();