//This code was written for the raspberry pi pico 
//Company:                  Fontys
//Maker of file:            Wouter Mulder 
//Last edded by:            Wouter Mulder 
//Date of file creation:    10-5-2022
//Date of last edded:       10-5-2022

#include "global.h"
#include <stdio.h>
#include "pico/stdlib.h"
#include "pico.h"
#include "hardware/structs/adc.h"
#include "hardware/gpio.h"




void motorDriveControll(uint8_t UL, uint8_t UH, uint8_t VL, uint8_t VH, uint8_t WL, uint8_t WH){

}
