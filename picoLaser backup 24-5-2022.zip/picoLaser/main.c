//This code was written for the raspberry pi pico 
//Company:                  Fontys
//Maker of file:            Wouter Mulder 
//Last edded by:            Wouter Mulder 
//Date of file creation:    10-5-2022
//Date of last edded:       10-5-2022

#include "global.h"
#include <stdio.h>
#include <stdint.h>
#include "pico/stdlib.h"
#include "pico.h"
#include "hardware/structs/adc.h"
#include "hardware/gpio.h"
#include "hardware/adc.h"
#include "pico/multicore.h"
#include "laser.h"
//#include "serial.h"
#include "statemachine.h"
#include "pwm.h"
//#include "hardware/watchdog.h"

 

void PINSETUP(void){
    //setup the ADC for current sensing
    adc_gpio_init(current_sense_X_pin);
    adc_gpio_init(current_sense_Y_pin);
    adc_select_input(current_sense_X);
    adc_select_input(current_sense_Y);

    //GPIO init function will initialoize the GPIO pins 
    gpio_init(WL_X);
    gpio_init(WH_X);
    gpio_init(VL_X);
    gpio_init(VH_X);
    gpio_init(UL_X);
    gpio_init(UH_X);
    gpio_init(WL_Y);
    gpio_init(WH_Y);
    gpio_init(VL_Y);
    gpio_init(VH_Y);
    gpio_init(UL_Y);
    gpio_init(UH_Y);
    gpio_init(RGB_green);
    gpio_init(RGB_red);
    gpio_init(RGB_blue);
    gpio_init(laser_enable);

    //GPIO set direction will make the pins input or output
    gpio_set_dir(WL_X, GPIO_OUT);
    gpio_set_dir(WH_X, GPIO_OUT);
    gpio_set_dir(VL_X, GPIO_OUT);
    gpio_set_dir(VH_X, GPIO_OUT);
    gpio_set_dir(UL_X, GPIO_OUT);
    gpio_set_dir(UH_X, GPIO_OUT);
    gpio_set_dir(WL_Y, GPIO_OUT);
    gpio_set_dir(WH_Y, GPIO_OUT);
    gpio_set_dir(VL_Y, GPIO_OUT);
    gpio_set_dir(VH_Y, GPIO_OUT);
    gpio_set_dir(UL_Y, GPIO_OUT);
    gpio_set_dir(UH_Y, GPIO_OUT);
    gpio_set_dir(RGB_green, GPIO_OUT);
    gpio_set_dir(RGB_red, GPIO_OUT);
    gpio_set_dir(RGB_blue, GPIO_OUT);
    gpio_set_dir(laser_enable, GPIO_OUT);
}

void second_core_code(void){
    StatesCore1 stateCoreOne = readSerial;
    struct motorPins motorXcore1;
    struct motorPins motorYcore1;
    uint8_t stringSerial[30];

 
    gpio_put(RGB_blue, RGB_ON);

    //To keep core 2 running 
    while(true){
        //Do some serial reading 
        switch(stateCoreOne){
            case(readSerial):
                //Do something 
                break;
            
            case(calculatePWM):
                //Do something 
                break;

            case(listenToCore0):
                //Do something 
                break;
            
            case(sentToCore0):
                //Do something 
                break;

            default:
                stateCoreOne = readSerial;
        }
        //Do the calculations for the laser 
    }
}

int main(void){
    
    States stateCoreZero = listenToCore1;
    static uint32_t dataFromCore1[3];
    struct motorPins motorXcore0;
    struct motorPins motorYcore0;
    
    //watchdog_enable(1000, 1);

    multicore_launch_core1(second_core_code);   //Start second core
    adc_init();
    PINSETUP();
    PWMSETUP();
    stdio_init_all();        // Initialize chosen serial port
    laserEnable(false, laser_enable);   //Trun off laser for safety 
    
    gpio_put(RGB_green, RGB_OFF);
    gpio_put(RGB_red, RGB_OFF);
    gpio_put(RGB_blue, RGB_OFF);


    //loop on first core 
    while(true){
        
        switch(stateCoreZero){
            case(listenToCore1):
                listenToCore1State(&stateCoreZero, &motorXcore0, &motorYcore0);
                break;

            case(sentToCore1):
                sentToCore1State(&stateCoreZero); 
                break;

            case(outputResults):
                outputResultsState(&stateCoreZero, motorXcore0, motorYcore0);
                break;

            default:
                stateCoreZero = listenToCore1;
                break;
        }

        //watchdog_update();
    }
}