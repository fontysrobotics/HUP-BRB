//This code was written for the raspberry pi pico 
//Company:                  Fontys
//Maker of file:            Wouter Mulder 
//Last edded by:            Wouter Mulder 
//Date of file creation:    10-5-2022
//Date of last edded:       10-5-2022

#include <stdint.h>

//This function helps with serial port decoding 
void serial_in(uint8_t *data[30]);