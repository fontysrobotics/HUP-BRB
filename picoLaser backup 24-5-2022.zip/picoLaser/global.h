//This code was written for the raspberry pi pico 
//Company:                  Fontys
//Maker of file:            Wouter Mulder 
//Last edded by:            Wouter Mulder 
//Date of file creation:    10-5-2022
//Date of last edded:       11-5-2022

#include <stdint.h>
#include <stdbool.h>

//Define pins 
//Digital
#define WL_X            4
#define WH_X            5
#define VL_X            6
#define VH_X            7
#define UL_X            8
#define UH_X            9
#define WL_Y            10
#define WH_Y            11
#define VL_Y            12
#define VH_Y            13
#define UL_Y            14
#define UH_Y            15

#define RGB_green       21
#define RGB_red         22
#define RGB_blue        18
#define RGB_ON          false
#define RGB_OFF         true

#define laser_enable    19

//Analog 
#define current_sense_X_pin 26
#define current_sense_Y_pin 27
#define current_sense_X 0
#define current_sense_Y 1

//DeadTime
#define DEADTIMEPOSITIVE 10
#define DEADTIMENEGATIVE -10

//High and low defines 
#define HIGH            true 
#define low             false          

#define PI              3.14159265359

