//This code was written for the raspberry pi pico 
//Company:                  Fontys
//Maker of file:            Wouter Mulder 
//Last edded by:            Wouter Mulder 
//Date of file creation:    10-5-2022
//Date of last edded:       10-5-2022

#include <stdint.h>

//Defining the PWM channels 
#define GPIO0PWM    0x0A
#define GPIO1PWM    0x0B
#define GPIO2PWM    0x1A
#define GPIO3PWM    0x1B
#define GPIO4PWM    0x2A
#define GPIO5PWM    0x2B
#define GPIO6PWM    0x3A
#define GPIO7PWM    0x3B
#define GPIO8PWM    0x4A
#define GPIO9PWM    0x4B
#define GPIO10PWM   0x5A
#define GPIO11PWM   0x5B
#define GPIO12PWM   0x6A
#define GPIO13PWM   0x6B
#define GPIO14PWM   0x7A
#define GPIO15PWM   0x7B
#define GPIO16PWM   0x0A
#define GPIO17PWM   0x0B
#define GPIO18PWM   0x1A
#define GPIO19PWM   0x1B
#define GPIO20PWM   0x2A
#define GPIO21PWM   0x2B
#define GPIO22PWM   0x3A
#define GPIO23PWM   0x3B
#define GPIO24PWM   0x4A
#define GPIO25PWM   0x4B
#define GPIO26PWM   0x5A
#define GPIO27PWM   0x5B
#define GPIO28PWM   0x6A
#define GPIO29PWM   0x6B

#define numberOfPwmCycles 255

void PWMSETUP(void);

void pwmSet(uint8_t pwmPin, uint8_t PWM);