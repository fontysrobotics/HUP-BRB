//This code was written for the raspberry pi pico 
//Company:                  Fontys
//Maker of file:            Wouter Mulder 
//Last edded by:            Wouter Mulder 
//Date of file creation:    10-5-2022
//Date of last edded:       11-5-2022

#include "statemachine.h"
#include "pwm.h"
#include "global.h"
#include <stdint.h>
#include <stdbool.h>

#include "pico/stdlib.h"
#include "pico.h"
#include "hardware/structs/adc.h"
#include "hardware/gpio.h"
#include "hardware/adc.h"
#include "pico/multicore.h"
#include <math.h>

//struct motorPins motor_X_core0;
//struct motorPins motor_Y_core0;
//struct motorPins motor_X_core1;
//struct motorPins motor_Y_core1;

//Core 0 statemachine--------------------------------------------------------------------------------------------------------------------------------------------

void listenToCore1State(States *stateInBlock, struct motorPins *motorX, struct motorPins *motorY){

    
    uint32_t dataFromCoreOne[3];

    for (int i = 0; i < 3;){
        uint32_t status =  multicore_fifo_get_status();
        uint8_t RX_buffer_not_empty = (1 << status) - 1;

        if (RX_buffer_not_empty == 1){
            dataFromCoreOne[i] = multicore_fifo_pop_blocking();
            i++;
        } 

        else{
            if (i == 10){
                errorSignalsCore0.notReadingCoreOne = true;
            }
            i++;
        }
    }

    //Bit shift the 3 32 bits integer over the bytes for PWM 
    (*motorX).WL = dataFromCoreOne[1] << 8;   
    (*motorX).WH = dataFromCoreOne[1] << 8;
    (*motorX).VL = dataFromCoreOne[1] << 8;
    (*motorX).VH = dataFromCoreOne[1] << 8;

    (*motorX).UL = dataFromCoreOne[2] << 8;   
    (*motorX).UH = dataFromCoreOne[2] << 8;
    (*motorY).WL = dataFromCoreOne[2] << 8;
    (*motorY).WH = dataFromCoreOne[2] << 8;

    (*motorY).VL = dataFromCoreOne[3] << 8;   
    (*motorY).VH = dataFromCoreOne[3] << 8;
    (*motorY).UL = dataFromCoreOne[3] << 8;
    (*motorY).UH = dataFromCoreOne[3] << 8;

    *stateInBlock = sentToCore1;
}

void sentToCore1State(States *stateInBlock){
    gpio_put(RGB_green, RGB_OFF);
    gpio_put(RGB_red, RGB_ON);
    gpio_put(RGB_blue, RGB_OFF);

    *stateInBlock = outputResults;
}

void outputResultsState(States *stateInBlock, struct motorPins motorX, struct motorPins motorY){

    
    //Set pwm from data in motor structs 
    pwmSet(WL_X, motorX.WL);
    pwmSet(WH_X, motorX.WH);
    pwmSet(VL_X, motorX.VL);
    pwmSet(VH_X, motorX.VH);
    pwmSet(VL_X, motorX.VL);
    pwmSet(UH_X, motorX.UH);

    pwmSet(WL_Y, motorY.WL);
    pwmSet(WH_Y, motorY.WH);
    pwmSet(VL_Y, motorY.VL);
    pwmSet(VH_Y, motorY.VH);
    pwmSet(UL_Y, motorY.UL);
    pwmSet(UH_Y, motorY.UH);


    *stateInBlock = listenToCore1;
}

//Core 1 statemachine-------------------------------------------------------------------------------------------------------------------------------------------

void readSerialState(StatesCore1 *stateInBlock, uint8_t *serialString[30]){
    
    serial_in(*serialString);       //Read serial bus and put charactes in de serial string 
    *stateInBlock = calculatePWM;
}

void calculatePWMState(StatesCore1 *stateInBlock, struct motorPins motorX, struct motorPins motorY, uint8_t serialString[30]){
    
    //Read in serial string 
    uint8_t xString[4];
    uint8_t yString[3];

    memcpy(xString, serialString, 4 * sizeof(int));
    memcpy(yString, serialString + 4, 3 * sizeof(int));
    
    //Calculate xy axis displasment 
    int16_t X_val = atoi(xString);

    if (xString[1] == '-'){
        X_val = X_val * -1;
    }

    int16_t Y_val = atoi(yString);

    //Calculate the sine and cosine functions 
    int16_t x_axis = X_val * sin(2 * PI) + X_val;
    int16_t y_axis = Y_val * cos(2 * PI); 

    //Calculate deadspace 
    if (x_axis < DEADTIMEPOSITIVE && x_axis > DEADTIMENEGATIVE){
        x_axis = 0;
    }

    if (y_axis < DEADTIMEPOSITIVE && y_axis > DEADTIMENEGATIVE){
        y_axis = 0;
    }

    

    *stateInBlock = listenToCore0;
}

void listenToCore0State(StatesCore1 *stateInBlock, uint32_t *dataFromCore0[3]){
     for (uint8_t i = 0; i < 3;){
        uint32_t status =  multicore_fifo_get_status();
        uint8_t RX_buffer_not_empty = (1 << status) - 1;

        if (RX_buffer_not_empty == 0x01){   //Check if the first bit is a one 
            *dataFromCore0[i] = multicore_fifo_pop_blocking();
            i++;
        } 
    }
    *stateInBlock = sentToCore0;
}

void sentToCore0State(StatesCore1 *stateInBlock){
    for (uint8_t i = 0; i < 3;){
        uint32_t status =  multicore_fifo_get_status();

        uint8_t TX_buffer_empty;

        if (TX_buffer_empty == 0x01){       //Check if first bit in a one 
            
        }
    }
    *stateInBlock = readSerial;
}