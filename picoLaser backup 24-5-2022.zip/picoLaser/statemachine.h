//This code was written for the raspberry pi pico 
//Company:                  Fontys
//Maker of file:            Wouter Mulder 
//Last edded by:            Wouter Mulder 
//Date of file creation:    10-5-2022
//Date of last edded:       11-5-2022

//#include "global.h"
#include <stdint.h>
#include <stdbool.h>

//Defining states for statemachine 
//States for core 0 state machine 
typedef enum{
    listenToCore1,
    sentToCore1,
    outputResults
} States;

//States for core 1 state machine 
typedef enum{
    readSerial,
    calculatePWM,
    listenToCore0,
    sentToCore0
} StatesCore1;

struct motorPins{
    uint8_t WL;            
    uint8_t WH;            
    uint8_t VL;            
    uint8_t VH;            
    uint8_t UL;            
    uint8_t UH;            
};

struct errorSignalsCore0{
    bool notReady;
    bool laserProblem;
    bool motorProblen;
    bool overCurrent;
    bool notReadingCoreOne;
};

//State machine core 0-------------------------------------------------------------------------------------
void listenToCore1State(States *stateInBlock, struct motorPins *motorX, struct motorPins *motorY);

void sentToCore1State(States *stateInBlock);

void outputResultsState(States *stateInBlock, struct motorPins motorX, struct motorPins motorY);

//State machine core 1---------------------------------------------------------------------------------------
void readSerialState(StatesCore1 *stateInBlock, uint8_t *serialString[30]);

void calculatePWMState(StatesCore1 *stateInBlock, struct motorPins motorX, struct motorPins motorY, uint8_t serialString[30]);

void listenToCore0State(StatesCore1 *stateInBlock, uint32_t *dataFromCore0[3]);

void sentToCore0State(StatesCore1 *stateInBlock);